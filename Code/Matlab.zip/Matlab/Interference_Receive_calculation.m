function Interference=Interference_Receive_calculation(PowerReceived,Noice)
Interference=PowerReceived+Noice;
end

